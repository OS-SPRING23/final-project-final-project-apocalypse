#include <linux/kernel.h>

#include <linux/syscalls.h>

asmlinkage long sys_printstatement( char *buff ,int id)

{

	printk("\n[BARBER SHOP]: Customer[%d]:%s",id,buff);

	return 0;

}
